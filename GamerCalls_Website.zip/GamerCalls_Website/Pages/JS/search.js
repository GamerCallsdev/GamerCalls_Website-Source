function openPage() 
{
    x = document.getElementById("search").value;
           
    if(x === "Home")
    {
        window.open("index.html")
    }

    if(x == "home")
    {
        window.open("index.html")
    }

    if(x == "GamerCalls")
    {
        window.open("index.html")
    }

    if(x == "gamercalls")
    {
        window.open("index.html")
    }

    if (x === "Contact GamerCalls")
    {
        window.open("contact.html")
    }

    if(x == "About GamerCalls")
    {
        window.open("about.html")
    }
                        
    if(x == "about gamercalls")
    {
        window.open("about.html")
    }

    if(x == "contact gamercalls")
    {
        window.open("contact.html")
    }

    if(x == "About")
    {
        window.open("about.html")
    }

    if(x == "about")
    {
        window.open("about.html")
    }

    if(x == "Contact")
    {
        window.open("contact.html")
    }

    if(x == "contact")
    {
        window.open("contact.html")
    }

    if(x == "GamerCalls Videos")
    {
        window.open("videos.html")
    }

    if(x == "gamercalls videos")
    {
        window.open("videos.html")
    }

    if(x == "Videos")
    {
        window.open("videos.html")
    }

    if(x == "videos")
    {
        window.open("videos.html")
    }
    
    if(x == "YouTube")
    {
        window.open("https://youtube.com/GamerCallsDoesStuff")
    }

    if(x == "Youtube")
    {
        window.open("https://youtube.com/GamerCallsDoesStuff")
    }

    if(x == "youtube")
    {
        window.open("https://youtube.com/GamerCallsDoesStuff")
    }

    if(x = "GamerCalls YouTube")
    {
        window.open("https://youtube.com/GamerCallsDoesStuff")
    }

    if(x == "GamerCalls Youtube")
    {
        window.open("https://youtube.com/GamerCallsDoesStuff")
    }
}